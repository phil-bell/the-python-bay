# the-python-bay

Python library for searching thepiratebay.org

## Install

    pip install the-python-bay

## Usage

```
from the_python_bay import tpb

tpb.search("ubunut")
```